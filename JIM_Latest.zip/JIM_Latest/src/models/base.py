"""
Base Model Interface
====================
All models implement this interface for consistent ensemble integration.
"""

from abc import ABC, abstractmethod
from typing import Optional, Tuple
import pandas as pd
import numpy as np
from loguru import logger


class BaseModel(ABC):
    """
    Abstract base class for all trading models.

    Every model must:
    1. Train on historical data
    2. Produce a signal (long/short/flat) with confidence
    3. Be serializable for MLflow tracking
    """

    def __init__(self, name: str, version: str = "1.0"):
        self.name = name
        self.version = version
        self.is_trained = False
        self.metadata = {}
        logger.info(f"Model initialized: {name} v{version}")

    @abstractmethod
    def train(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> dict:
        """
        Train the model.

        Args:
            X: Feature matrix.
            y: Target variable (optional — some models are unsupervised).

        Returns:
            Training metrics dict (loss, accuracy, etc.).
        """
        pass

    @abstractmethod
    def predict(self, X: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate predictions.

        Args:
            X: Feature matrix for prediction.

        Returns:
            Tuple of (signals, confidences):
              - signals: array of -1 (short), 0 (flat), 1 (long)
              - confidences: array of [0, 1] confidence scores
        """
        pass

    @abstractmethod
    def save(self, path: str) -> None:
        """Save model to disk."""
        pass

    @abstractmethod
    def load(self, path: str) -> None:
        """Load model from disk."""
        pass

    def get_info(self) -> dict:
        """Return model metadata."""
        return {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            **self.metadata,
        }
