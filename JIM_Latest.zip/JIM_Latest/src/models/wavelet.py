"""
Wavelet De-noising Model
=========================
Uses Discrete Wavelet Transform to separate signal from noise.
This is our "microscope" — it reveals patterns hidden in the raw price.
"""

import numpy as np
import pandas as pd
import pywt
from typing import Optional, Tuple
from loguru import logger

from src.models.base import BaseModel


class WaveletDenoiser(BaseModel):
    """
    Wavelet-based signal extractor for gold prices.

    Decomposes price into frequency bands and reconstructs
    without the high-frequency noise components.
    """

    def __init__(
        self,
        wavelet: str = "db4",
        levels: int = 5,
        remove_levels: list = None,
        version: str = "1.0",
    ):
        super().__init__(name="WaveletDenoiser", version=version)
        self.wavelet = wavelet
        self.levels = levels
        self.remove_levels = remove_levels or [1, 2]
        self.metadata = {
            "wavelet": wavelet,
            "levels": levels,
            "remove_levels": self.remove_levels,
        }

    def denoise(self, signal: np.ndarray) -> np.ndarray:
        """
        Remove noise from a price signal using DWT.

        Args:
            signal: Raw price array.

        Returns:
            De-noised price array.
        """
        # Decompose
        coeffs = pywt.wavedec(signal, self.wavelet, level=self.levels)

        # Zero out noise levels (detail coefficients at high frequencies)
        for level in self.remove_levels:
            if level < len(coeffs):
                coeffs[level] = np.zeros_like(coeffs[level])

        # Reconstruct
        denoised = pywt.waverec(coeffs, self.wavelet)

        # Match length (waverec can add 1 sample)
        return denoised[:len(signal)]

    def extract_trend(self, signal: np.ndarray) -> np.ndarray:
        """Extract only the low-frequency trend component."""
        coeffs = pywt.wavedec(signal, self.wavelet, level=self.levels)
        # Keep only approximation coefficients (lowest frequency)
        for i in range(1, len(coeffs)):
            coeffs[i] = np.zeros_like(coeffs[i])
        trend = pywt.waverec(coeffs, self.wavelet)
        return trend[:len(signal)]

    def get_frequency_bands(self, signal: np.ndarray) -> dict:
        """
        Decompose signal into named frequency bands.

        Returns:
            Dict with keys: 'noise', 'short_term', 'medium', 'trend', 'structural'
        """
        coeffs = pywt.wavedec(signal, self.wavelet, level=self.levels)
        band_names = ["structural", "trend", "medium", "short_term", "noise"]

        bands = {}
        for i, name in enumerate(band_names[:len(coeffs)]):
            # Reconstruct each band individually
            band_coeffs = [np.zeros_like(c) for c in coeffs]
            idx = min(i, len(coeffs) - 1)
            band_coeffs[idx] = coeffs[idx]
            band_signal = pywt.waverec(band_coeffs, self.wavelet)
            bands[name] = band_signal[:len(signal)]

        return bands

    def generate_signal(self, prices: np.ndarray, lookback: int = 20) -> Tuple[int, float]:
        """
        Generate a trading signal from wavelet analysis.

        Logic:
        - De-noise the price
        - Compare current de-noised slope to recent slope
        - If slope is accelerating up → long signal
        - If slope is accelerating down → short signal

        Returns:
            Tuple of (signal, confidence):
              signal: -1, 0, or 1
              confidence: 0.0 to 1.0
        """
        if len(prices) < lookback + self.levels * 2:
            return 0, 0.0

        denoised = self.denoise(prices)

        # Compute slope of de-noised signal
        recent = denoised[-lookback:]
        slope = np.polyfit(range(len(recent)), recent, 1)[0]
        prev_slope = np.polyfit(range(len(recent) - 5), recent[:-5], 1)[0]

        # Normalize slope by price level
        norm_slope = slope / prices[-1]
        slope_change = slope - prev_slope

        # Generate signal based on slope direction and acceleration
        threshold = np.std(np.diff(denoised[-100:])) * 0.5

        if norm_slope > threshold and slope_change > 0:
            signal = 1  # Long
            confidence = min(abs(norm_slope / threshold) * 0.5, 1.0)
        elif norm_slope < -threshold and slope_change < 0:
            signal = -1  # Short
            confidence = min(abs(norm_slope / threshold) * 0.5, 1.0)
        else:
            signal = 0  # Flat
            confidence = 0.0

        return signal, confidence

    # --- BaseModel interface ---
    def train(self, X: pd.DataFrame, y=None) -> dict:
        """Wavelets don't train — they transform. Mark as ready."""
        self.is_trained = True
        return {"status": "ready", "wavelet": self.wavelet, "levels": self.levels}

    def predict(self, X: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Generate signals for each row using rolling wavelet analysis."""
        prices = X["close"].values
        signals = np.zeros(len(prices))
        confidences = np.zeros(len(prices))

        min_len = 200  # Need enough history for wavelet
        for i in range(min_len, len(prices)):
            sig, conf = self.generate_signal(prices[:i+1])
            signals[i] = sig
            confidences[i] = conf

        return signals, confidences

    def save(self, path: str) -> None:
        import joblib
        joblib.dump(self.__dict__, path)

    def load(self, path: str) -> None:
        import joblib
        state = joblib.load(path)
        self.__dict__.update(state)
